const assert = require('chai').assert;

describe('1 + 1', function() {
	it('should equal 2', function() {
		assert.strictEqual((1 + 1), 2);
	});
});