var express = require('express');
var router = express.Router();
var passport = require('passport');
const bcrypt = require('bcrypt');
const saltRounds = 10;
/* GET home page. */

router.get('/', function(req, res){
  console.log(req.user);
  console.log(req.isAuthenticated());
  res.render('home', { title: 'Home' });
});

router.get('/profile',authenticationMiddleware(), function (req, res){
  res.render('profile',{ title: 'Profile'})
});

router.get('/login', function (req, res){
  res.render('login',{ title: 'Login'})
});

router.post('/login', passport.authenticate(
    'local', {
      successRedirect: '/profile',
      failureRedirect: '/login'
    }
));

router.get('/logout', function (req, res){
  req.logout();
  req.session.destroy();
  res.redirect('/');
});

router.get('/register', function(req, res, next) {
  res.render('register', { title: 'Registration' });
});

router.post('/register', function(req, res, next)
{
  const username = req.body.username;
  const password = req.body.password;
  const email = req.body.email;


  const db = require('../db.js');

  bcrypt.hash(password, saltRounds, function(err, hash) {
    // Store hash in your password DB.

    db.query('INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
        [username, email, hash], function(error, results, fields) {
          if (error) throw error;

          db.query('SELECT LAST_INSERT_ID() as user_id', function(error, results, fields) {
            if(error) throw error;

            const user_id = results[0];

            console.log(results[0]);
            req.login(user_id, function(err) {
              res.redirect('/');
            })
          });
        })
  });
});

passport.serializeUser(function(user_id, done) {
  done(null,user_id);
});

passport.deserializeUser(function(user_id, done) {

    done(null, user_id);

});
function authenticationMiddleware () {
  return (req, res, next) => {
    console.log(`req.session.passport.user: ${JSON.stringify(req.session.passport)}`);

    if (req.isAuthenticated()) return next();
    res.redirect('/login')
  }
}

module.exports = router;
